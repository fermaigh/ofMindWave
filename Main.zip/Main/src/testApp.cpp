#include "testApp.h"

//--------------------------------------------------------------
void testApp::setup(){
    
    fingerMovie.loadMovie("movies/startscreen_audio.mov");
	fingerMovie.play();
    
    
    blur.setup(fingerMovie.getWidth(), fingerMovie.getHeight(), 4, .2, 4);
    
    gameplay.loadMovie("movies/Level one_with audio.mov");
    gameplay.play();
    
    
    
    thinkGear.setup();
    ofAddListener(thinkGear.attentionChangeEvent, this, &testApp::attentionListener);
    
    
    distAw = 0.0;
    prevAw = 0.0;
    currAw = 0.0;
    
    
    
    atChangeTime = 0.0;
    attention = 0.0;
    
    atChangeTime = 0.0;
    attention = 0.0;

    
    currBlur= 0.0;
    


}

//--------------------------------------------------------------
void testApp::update(){
    
    fingerMovie.update();
    blur.setScale(ofMap(attention, 0, currBlur, 1, 100));
	blur.setRotation(ofMap(attention, 0, currBlur, -PI, PI));
    
    thinkGear.update();
    
    gameplay.update();
    

}

//--------------------------------------------------------------
void testApp::draw(){
    
    //ofSetWindowTitle("INCIDENT    fps = " + ofToString(ofGetFrameRate()));


    blur.begin();
	fingerMovie.draw(0,0);
	blur.end();
	blur.draw();

    
    if (attention >= 30.0)
    {
        ofSetColor(ofColor::white);
        ofRect(150, 200, 40, 40);
        gameplay.draw(0,0);
        
    } else{
        ofSetColor(ofColor::white);
        ofCircle(150, 200, 20);
    }

    
}

void testApp::attentionListener(float &param)
{
    attention = param;
    currBlur = ofMap(attention, 0.0, 100.0, 0, ofGetWidth());
}



//--------------------------------------------------------------
void testApp::keyPressed(int key){

}

//--------------------------------------------------------------
void testApp::keyReleased(int key){

}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void testApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void testApp::dragEvent(ofDragInfo dragInfo){ 

}